import React, { useState } from 'react';

const SimpleAudioPlayer = () => {
  const [currentTrack, setCurrentTrack] = useState(0);

  // Simple test tracks with reliable audio sources
  const testTracks = [
    {
      title: "Sample Piano",
      artist: "MoodWaves Demo",
      url: "https://www.learningcontainer.com/wp-content/uploads/2020/02/Kalimba.mp3"
    },
    {
      title: "Night Owl", 
      artist: "Broke For Free",
      url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/WFMU/Broke_For_Free/Directionless_EP/Broke_For_Free_-_01_-_Night_Owl.mp3"
    },
    {
      title: "Tomorrow",
      artist: "Josh Woodward", 
      url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/Creative_Commons/Josh_Woodward/The_Simple_Life/Josh_Woodward_-_The_Simple_Life_-_08_-_Tomorrow.mp3"
    }
  ];

  return (
    <div style={{
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      borderRadius: '15px',
      padding: '20px',
      color: 'white',
      maxWidth: '400px',
      margin: '20px auto'
    }}>
      <h3 style={{ textAlign: 'center', marginBottom: '20px' }}>
        🎵 Simple Audio Test
      </h3>

      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h4>{testTracks[currentTrack].title}</h4>
        <p style={{ opacity: 0.8 }}>{testTracks[currentTrack].artist}</p>
      </div>

      {/* HTML5 Audio Element with Controls */}
      <audio 
        key={currentTrack} // Force reload when track changes
        controls 
        style={{ width: '100%', marginBottom: '20px' }}
        preload="metadata"
      >
        <source src={testTracks[currentTrack].url} type="audio/mpeg" />
        <source src={testTracks[currentTrack].url} type="audio/wav" />
        Your browser does not support the audio element.
      </audio>

      {/* Track Selection */}
      <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
        {testTracks.map((track, index) => (
          <button
            key={index}
            onClick={() => setCurrentTrack(index)}
            style={{
              background: currentTrack === index ? 'rgba(255,255,255,0.3)' : 'rgba(255,255,255,0.1)',
              border: '1px solid rgba(255,255,255,0.3)',
              color: 'white',
              padding: '8px 12px',
              borderRadius: '20px',
              cursor: 'pointer',
              fontSize: '12px'
            }}
          >
            Track {index + 1}
          </button>
        ))}
      </div>

      <div style={{
        marginTop: '15px',
        textAlign: 'center',
        fontSize: '12px',
        opacity: 0.8
      }}>
        Use the audio controls above to play/pause, adjust volume, and seek.
      </div>
    </div>
  );
};

export default SimpleAudioPlayer;